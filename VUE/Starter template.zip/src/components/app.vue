<template>
  <div class="text-center">
    <div class="mb-3 text-4xl">Vue3 Primevue3 Template</div>

    <Button label="Click Me" icon="pi pi-check" />
  </div>
</template>
<script setup></script>

<style>
.module {
  overflow: unset !important;
}
.moduleWrapper {
  overflow: inherit !important;
}
#app {
  font-family: "Roboto";
}
.v-application--wrap {
  background-color: #f4f5f6 !important;
}
</style>
